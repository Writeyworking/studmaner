import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";
import OpenAI from "openai";

export const getChatHistory = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db
      .query("chatMessages")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(10);
  },
});

export const askAI = action({
  args: {
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const openai = new OpenAI({
      baseURL: process.env.CONVEX_OPENAI_BASE_URL,
      apiKey: process.env.CONVEX_OPENAI_API_KEY,
    });

    const systemPrompt = `You are a helpful AI assistant for college students. You help with:
    - Academic questions and study tips
    - Time management and organization
    - Assignment planning and task prioritization
    - General college life advice
    - Personal productivity tips
    
    Keep your responses concise, helpful, and encouraging. Focus on practical advice.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: args.message }
      ],
      max_tokens: 500,
    });

    const aiResponse = response.choices[0].message.content || "I'm sorry, I couldn't generate a response.";

    await ctx.runMutation(api.chat.saveChatMessage, {
      message: args.message,
      response: aiResponse,
    });

    return aiResponse;
  },
});

export const saveChatMessage = mutation({
  args: {
    message: v.string(),
    response: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    await ctx.db.insert("chatMessages", {
      message: args.message,
      response: args.response,
      userId,
    });
  },
});
