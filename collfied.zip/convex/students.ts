import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getStudents = query({
  args: {
    search: v.optional(v.string()),
    course: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (args.search) {
      return await ctx.db
        .query("students")
        .withSearchIndex("search_students", (q) =>
          q.search("name", args.search!).eq("userId", userId)
        )
        .collect();
    }

    return await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const createStudent = mutation({
  args: {
    name: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    course: v.optional(v.string()),
    year: v.optional(v.string()),
    rollNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("students", {
      ...args,
      userId,
    });
  },
});

export const updateStudent = mutation({
  args: {
    studentId: v.id("students"),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    course: v.optional(v.string()),
    year: v.optional(v.string()),
    rollNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const student = await ctx.db.get(args.studentId);
    if (!student || student.userId !== userId) {
      throw new Error("Student not found or unauthorized");
    }

    const { studentId, ...updates } = args;
    const filteredUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );

    await ctx.db.patch(args.studentId, filteredUpdates);
  },
});

export const deleteStudent = mutation({
  args: { studentId: v.id("students") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const student = await ctx.db.get(args.studentId);
    if (!student || student.userId !== userId) {
      throw new Error("Student not found or unauthorized");
    }

    await ctx.db.delete(args.studentId);
  },
});
