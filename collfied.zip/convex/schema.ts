import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  tasks: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    type: v.union(v.literal("college"), v.literal("personal")),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    status: v.union(v.literal("pending"), v.literal("in-progress"), v.literal("completed")),
    dueDate: v.optional(v.number()),
    userId: v.id("users"),
  })
    .index("by_user", ["userId"])
    .index("by_user_and_status", ["userId", "status"])
    .index("by_user_and_type", ["userId", "type"]),

  students: defineTable({
    name: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    course: v.optional(v.string()),
    year: v.optional(v.string()),
    rollNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
    userId: v.id("users"),
  })
    .index("by_user", ["userId"])
    .searchIndex("search_students", {
      searchField: "name",
      filterFields: ["userId", "course"],
    }),

  schedules: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    startTime: v.number(),
    endTime: v.number(),
    type: v.union(v.literal("class"), v.literal("meeting"), v.literal("personal"), v.literal("exam")),
    location: v.optional(v.string()),
    userId: v.id("users"),
  })
    .index("by_user", ["userId"])
    .index("by_user_and_date", ["userId", "startTime"]),

  chatMessages: defineTable({
    message: v.string(),
    response: v.string(),
    userId: v.id("users"),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
