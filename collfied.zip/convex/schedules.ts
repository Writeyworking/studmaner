import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getSchedules = query({
  args: {
    date: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (args.date) {
      const startOfDay = new Date(args.date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(args.date);
      endOfDay.setHours(23, 59, 59, 999);

      return await ctx.db
        .query("schedules")
        .withIndex("by_user_and_date", (q) =>
          q.eq("userId", userId).gte("startTime", startOfDay.getTime()).lte("startTime", endOfDay.getTime())
        )
        .order("asc")
        .collect();
    }

    return await ctx.db
      .query("schedules")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("asc")
      .collect();
  },
});

export const createSchedule = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    startTime: v.number(),
    endTime: v.number(),
    type: v.union(v.literal("class"), v.literal("meeting"), v.literal("personal"), v.literal("exam")),
    location: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("schedules", {
      ...args,
      userId,
    });
  },
});

export const deleteSchedule = mutation({
  args: { scheduleId: v.id("schedules") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const schedule = await ctx.db.get(args.scheduleId);
    if (!schedule || schedule.userId !== userId) {
      throw new Error("Schedule not found or unauthorized");
    }

    await ctx.db.delete(args.scheduleId);
  },
});
