import { useState } from "react";
import { useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function ChatView() {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const chatHistory = useQuery(api.chat.getChatHistory);
  const askAI = useAction(api.chat.askAI);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || isLoading) return;

    setIsLoading(true);
    try {
      await askAI({ message: message.trim() });
      setMessage("");
    } catch (error) {
      toast.error("Failed to get AI response");
    } finally {
      setIsLoading(false);
    }
  };

  const suggestedQuestions = [
    "How can I manage my time better as a student?",
    "What are some effective study techniques?",
    "How do I prioritize my assignments?",
    "Tips for staying organized in college?",
    "How to balance college and personal life?",
  ];

  return (
    <div className="p-6 h-full flex flex-col">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Assistant</h1>
        <p className="text-gray-600">Ask me anything about college life, study tips, or task management!</p>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto mb-6 space-y-4">
        {chatHistory?.slice().reverse().map((chat) => (
          <div key={chat._id} className="space-y-3">
            {/* User Message */}
            <div className="flex justify-end">
              <div className="bg-blue-600 text-white rounded-lg px-4 py-2 max-w-[70%]">
                <p>{chat.message}</p>
              </div>
            </div>
            
            {/* AI Response */}
            <div className="flex justify-start">
              <div className="bg-gray-100 text-gray-900 rounded-lg px-4 py-2 max-w-[70%]">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg">🤖</span>
                  <span className="font-medium text-sm text-gray-600">AI Assistant</span>
                </div>
                <p className="whitespace-pre-wrap">{chat.response}</p>
              </div>
            </div>
          </div>
        ))}

        {chatHistory?.length === 0 && (
          <div className="text-center py-8">
            <div className="text-6xl mb-4">🤖</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Welcome to your AI Assistant!</h3>
            <p className="text-gray-600 mb-6">I'm here to help you with college and personal task management.</p>
            
            <div className="space-y-2">
              <p className="font-medium text-gray-700">Try asking:</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {suggestedQuestions.map((question, index) => (
                  <button
                    key={index}
                    onClick={() => setMessage(question)}
                    className="text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded-full hover:bg-blue-100 transition-colors"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Message Input */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Ask me anything about college life or task management..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={!message.trim() || isLoading}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? "..." : "Send"}
        </button>
      </form>
    </div>
  );
}
