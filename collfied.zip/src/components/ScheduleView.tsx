import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

type ScheduleType = "class" | "meeting" | "personal" | "exam";

export function ScheduleView() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startTime: "",
    endTime: "",
    type: "class" as ScheduleType,
    location: "",
  });

  const schedules = useQuery(api.schedules.getSchedules, {
    date: new Date(selectedDate).getTime(),
  });
  const createSchedule = useMutation(api.schedules.createSchedule);
  const deleteSchedule = useMutation(api.schedules.deleteSchedule);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const startDateTime = new Date(`${selectedDate}T${formData.startTime}`);
      const endDateTime = new Date(`${selectedDate}T${formData.endTime}`);

      await createSchedule({
        title: formData.title,
        description: formData.description || undefined,
        startTime: startDateTime.getTime(),
        endTime: endDateTime.getTime(),
        type: formData.type,
        location: formData.location || undefined,
      });

      setFormData({
        title: "",
        description: "",
        startTime: "",
        endTime: "",
        type: "class",
        location: "",
      });
      setShowForm(false);
      toast.success("Event scheduled successfully!");
    } catch (error) {
      toast.error("Failed to create event");
    }
  };

  const handleDelete = async (scheduleId: string) => {
    if (confirm("Are you sure you want to delete this event?")) {
      try {
        await deleteSchedule({ scheduleId: scheduleId as any });
        toast.success("Event deleted!");
      } catch (error) {
        toast.error("Failed to delete event");
      }
    }
  };

  const getTypeColor = (type: ScheduleType) => {
    switch (type) {
      case "exam": return "bg-red-100 text-red-800 border-red-200";
      case "class": return "bg-blue-100 text-blue-800 border-blue-200";
      case "meeting": return "bg-purple-100 text-purple-800 border-purple-200";
      case "personal": return "bg-green-100 text-green-800 border-green-200";
    }
  };

  const getTypeIcon = (type: ScheduleType) => {
    switch (type) {
      case "exam": return "📝";
      case "class": return "📚";
      case "meeting": return "👥";
      case "personal": return "🏠";
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Schedule</h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Add Event
        </button>
      </div>

      {/* Date Selector */}
      <div className="mb-6">
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      {/* Schedule Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">Add New Event</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                placeholder="Event title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <textarea
                placeholder="Description (optional)"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                rows={3}
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="time"
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                />
                <input
                  type="time"
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as ScheduleType })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="class">Class</option>
                <option value="meeting">Meeting</option>
                <option value="personal">Personal</option>
                <option value="exam">Exam</option>
              </select>
              <input
                type="text"
                placeholder="Location (optional)"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add Event
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Schedule List */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900">
          {new Date(selectedDate).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </h2>
        
        {schedules?.map((event) => (
          <div key={event._id} className={`rounded-lg p-4 border-l-4 ${getTypeColor(event.type)}`}>
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{getTypeIcon(event.type)}</span>
                  <h3 className="font-semibold text-gray-900">{event.title}</h3>
                </div>
                {event.description && (
                  <p className="text-gray-600 mb-2">{event.description}</p>
                )}
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>
                    🕐 {new Date(event.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - 
                    {new Date(event.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {event.location && (
                    <span>📍 {event.location}</span>
                  )}
                  <span className="capitalize">🏷️ {event.type}</span>
                </div>
              </div>
              <button
                onClick={() => handleDelete(event._id)}
                className="text-red-600 hover:text-red-800 p-1 ml-4"
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
        
        {(!schedules || schedules.length === 0) && (
          <div className="text-center py-8">
            <p className="text-gray-500">No events scheduled for this date.</p>
          </div>
        )}
      </div>
    </div>
  );
}
