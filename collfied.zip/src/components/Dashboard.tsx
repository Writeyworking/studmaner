import { useState } from "react";
import { TasksView } from "./TasksView";
import { StudentsView } from "./StudentsView";
import { ScheduleView } from "./ScheduleView";
import { ChatView } from "./ChatView";
import { DashboardOverview } from "./DashboardOverview";

type View = "overview" | "tasks" | "students" | "schedule" | "chat";

export function Dashboard() {
  const [currentView, setCurrentView] = useState<View>("overview");

  const navigation = [
    { id: "overview", name: "Overview", icon: "📊" },
    { id: "tasks", name: "Tasks", icon: "✅" },
    { id: "students", name: "Students", icon: "👥" },
    { id: "schedule", name: "Schedule", icon: "📅" },
    { id: "chat", name: "AI Assistant", icon: "🤖" },
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-gray-200 p-4">
        <nav className="space-y-2">
          {navigation.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id as View)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                currentView === item.id
                  ? "bg-blue-50 text-blue-600 border border-blue-200"
                  : "text-gray-700 hover:bg-gray-50"
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="font-medium">{item.name}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {currentView === "overview" && <DashboardOverview />}
        {currentView === "tasks" && <TasksView />}
        {currentView === "students" && <StudentsView />}
        {currentView === "schedule" && <ScheduleView />}
        {currentView === "chat" && <ChatView />}
      </div>
    </div>
  );
}
