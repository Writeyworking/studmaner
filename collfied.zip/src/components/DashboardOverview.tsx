import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function DashboardOverview() {
  const allTasks = useQuery(api.tasks.getTasks, {});
  const todaySchedule = useQuery(api.schedules.getSchedules, {
    date: Date.now(),
  });
  const students = useQuery(api.students.getStudents, {});

  const pendingTasks = allTasks?.filter(task => task.status === "pending") || [];
  const completedTasks = allTasks?.filter(task => task.status === "completed") || [];
  const collegeTasks = allTasks?.filter(task => task.type === "college") || [];
  const personalTasks = allTasks?.filter(task => task.type === "personal") || [];

  const stats = [
    {
      title: "Total Tasks",
      value: allTasks?.length || 0,
      color: "bg-blue-500",
      icon: "📋",
    },
    {
      title: "Pending Tasks",
      value: pendingTasks.length,
      color: "bg-yellow-500",
      icon: "⏳",
    },
    {
      title: "Completed Tasks",
      value: completedTasks.length,
      color: "bg-green-500",
      icon: "✅",
    },
    {
      title: "Students",
      value: students?.length || 0,
      color: "bg-purple-500",
      icon: "👥",
    },
  ];

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard Overview</h1>
        <p className="text-gray-600">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-lg ${stat.color} flex items-center justify-center text-white text-xl`}>
                {stat.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tasks */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Tasks</h2>
          <div className="space-y-3">
            {pendingTasks.slice(0, 5).map((task) => (
              <div key={task._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-3 h-3 rounded-full ${
                  task.priority === "high" ? "bg-red-500" :
                  task.priority === "medium" ? "bg-yellow-500" : "bg-green-500"
                }`}></div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{task.title}</p>
                  <p className="text-sm text-gray-600 capitalize">{task.type} • {task.priority} priority</p>
                </div>
              </div>
            ))}
            {pendingTasks.length === 0 && (
              <p className="text-gray-500 text-center py-4">No pending tasks</p>
            )}
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Today's Schedule</h2>
          <div className="space-y-3">
            {todaySchedule?.slice(0, 5).map((event) => (
              <div key={event._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-3 h-3 rounded-full ${
                  event.type === "exam" ? "bg-red-500" :
                  event.type === "class" ? "bg-blue-500" :
                  event.type === "meeting" ? "bg-purple-500" : "bg-green-500"
                }`}></div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{event.title}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(event.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - 
                    {new Date(event.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            {(!todaySchedule || todaySchedule.length === 0) && (
              <p className="text-gray-500 text-center py-4">No events scheduled for today</p>
            )}
          </div>
        </div>
      </div>

      {/* Task Distribution */}
      <div className="mt-6 bg-white rounded-lg p-6 shadow-sm border border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Task Distribution</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-gray-700 mb-2">By Type</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">College Tasks</span>
                <span className="font-semibold">{collegeTasks.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Personal Tasks</span>
                <span className="font-semibold">{personalTasks.length}</span>
              </div>
            </div>
          </div>
          <div>
            <h3 className="font-medium text-gray-700 mb-2">By Status</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Pending</span>
                <span className="font-semibold">{pendingTasks.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">In Progress</span>
                <span className="font-semibold">{allTasks?.filter(t => t.status === "in-progress").length || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Completed</span>
                <span className="font-semibold">{completedTasks.length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
